PASOS SEGUIDOS PARA DESARROLLAR ESTE PROYECTO
---------------------------------------------

1. Convertir el c�digo del servlet en un servicio RESTful
2. Crear interfaz Swagger asociada a ese servlet
3. Hay que usar jquery:
	a. remplazar expresiones de HTML DOM por sentencias de jQuery
	b. remplazar uso de objeto XMLHttpRequest por $.ajax o m�todos 
           alternativos de uso de AJAX desde jQuery
4. Usar Bootstrap. Dar lugar a interfaz m�s atractiva, 
   que sea responsiva de conversor de n�meros romanos a �rabes
5. Usar AngularJS para que la l�gica de la parte cliente sea m�s elegante 
y mantenible
6. Recuperar colecci�n con objetos JSON: a) tipo de conversi�n, b) n�mero de origin, c) resultado y d) timestamp
	- Observar que la parte de serializaci�n est� hecha en: Tutorial a Objectify: https://cloud.google.com/appengine/docs/java/gettingstarted/usingdatastore 


PASOS PARA COMPILAR, PROBAR Y SUBIR EL PROYECTO A GOOGLE APP ENGINE
-------------------------------------------------------------------
1. Pasos para compilar el proyecto GAE, que hace uso de Swagger y Jersey:
	mvn clean 
	mvn -Dmaven.test.skip=true package
	mvn -Dmaven.test.skip=true appengine:devserver
2. Para ejecutar el servicio:
	a. Copiar el fichero conversor.war generado en carpeta target a webapps en Tomcat
	b. Lanzar Tomcat: catalina.bat run
3. Para probar el servicio:
	- Ir a un navegador y probar el servicio RESTful:
		a. http://localhost:8080/
		b. http://localhost:8080/webapi/swagger.json
		c. http://localhost:8080/webapi/conversor/roman/XII
		d. http://localhost:8080/index_romanJQueryBootstrap.html
4. Para subir la aplicaci�n a Google App Engine	
	a. Ir Google Cloud Platform Developer Console: https://console.cloud.google.com/home/dashboard
	b. Crear un nombre de app: usernamearab2romanconversor (cada uno de vosotros tiene que definir su propio nombre de app, por ejemplo dipinaarab2romanconversor)
	c. Actualizar el fichero EjercicioRomanGAE\src\main\webapp\WEB-INF\appengine-web.xml
		- Campo <application>milibrovisitas</application>
	d. Ejecutar el comando en el directorio donde est� pom.xml: 
		mvn -Dmaven.test.skip=true appengine:update
	e. Probar la aplicaci�n yendo a: http://nombre-ap.appspot.com/index_romanJQueryBootstrap.html. 
	En mi caso: http://milibrovisitas.appspot.com/index_romanJQueryBootstrap.html

Explicaci�n de error que se produc�a al subir la app
----------------------------------------------------

Se produc�a un error como el siguiente:
loading application configuration:Unable to assign value does not match expression '^(?:^(\-]{0,62}[a-z\d]$)$'

La respuesta m�s votada en: http://stackoverflow.com/questions/18239234/bad-request-when-updating-appengine-with-mvn-appengineupdate

Es la soluci�n al problema.