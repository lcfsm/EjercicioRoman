package es.deusto.ptsi;

import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Response;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

import com.google.appengine.api.datastore.QueryResultIterable;
import com.googlecode.objectify.ObjectifyService;

/**
 * Root resource (exposed at "/conversor" path)
 */
 
 
// Plain old Java Object it does not extend as class or implements an interface

// The class registers its methods for the HTTP GET request using the @GET annotation. 
// Using the @Produces annotation, it defines that it can deliver several MIME types,
// text, XML and HTML. 

// The browser requests per default the HTML MIME type.

//Sets the path to base URL + /hello
 
@Path("/conversor")
@Api(value="conversor", description="Roman to Arab Conversor")
public class Conversor {
	
	public enum NumeroRomanoEnum { I, V, X, L, C, D, M }
    
    private HashMap<String, NumeroRomanoEnum> equivalenciasRomanoArabe = new HashMap<String, NumeroRomanoEnum>();
    private HashMap<NumeroRomanoEnum, Integer> roman2Decimal = new HashMap<NumeroRomanoEnum, Integer>();
	
	public Conversor() {
        this.equivalenciasRomanoArabe.put("I", NumeroRomanoEnum.I);
        this.equivalenciasRomanoArabe.put("V", NumeroRomanoEnum.V);
        this.equivalenciasRomanoArabe.put("X", NumeroRomanoEnum.X);
        this.equivalenciasRomanoArabe.put("L", NumeroRomanoEnum.L);
        this.equivalenciasRomanoArabe.put("C", NumeroRomanoEnum.C);
        this.equivalenciasRomanoArabe.put("D", NumeroRomanoEnum.D);
        this.equivalenciasRomanoArabe.put("M", NumeroRomanoEnum.M);
        
        this.roman2Decimal.put(NumeroRomanoEnum.I, 1);
        this.roman2Decimal.put(NumeroRomanoEnum.V, 5);
        this.roman2Decimal.put(NumeroRomanoEnum.X, 10);
        this.roman2Decimal.put(NumeroRomanoEnum.L, 50);
        this.roman2Decimal.put(NumeroRomanoEnum.C, 100);
		this.roman2Decimal.put(NumeroRomanoEnum.D, 500);
		this.roman2Decimal.put(NumeroRomanoEnum.M, 1000);     

		
    }
	
	public String convertDecimal2Roman(int num) throws Exception {
		if ((num < 4000) && (num >= 0)) {
			if (num >= 1000) {
				return "M" + (this.convertDecimal2Roman(num-1000));
			} else if (num >= 900) {
				return "CM" + (this.convertDecimal2Roman(num-900));
			} else if (num >= 500) {
				return "D" + (this.convertDecimal2Roman(num-500));
			} else if (num >= 400) {
				return "CD" + (this.convertDecimal2Roman(num-400));
			} else if (num >= 100) {
				return "C" + (this.convertDecimal2Roman(num-100));
			} else if (num >= 90) {
				return "XC" + (this.convertDecimal2Roman(num-90));
			} else if (num >= 50) {
				return "L" + (this.convertDecimal2Roman(num-50));
			} else if (num >= 40) {
				return "XL" + (this.convertDecimal2Roman(num-40));
			} else if (num >= 10) {
				return "X" + (this.convertDecimal2Roman(num-10));
			} else if (num >= 9) {
				return "IX" + (this.convertDecimal2Roman(num-9));
			} else if (num >= 5) {
				return "V" + (this.convertDecimal2Roman(num-5));
			} else if (num >= 4) {
				return "IV" + (this.convertDecimal2Roman(num-4));
			} else if (num >= 1) {
				return "I" + (this.convertDecimal2Roman(num-1));
			} else if (num == 0) {
				return "";
			}
		} 
		throw new Exception("Número es mayor que 4000");
    }
    
    public int convertRoman2Decimal(String numRomano) throws Exception {
		int maxRomanDigit = -1;
		int valorArabeCalculado = 0;
						
		for (int i=numRomano.length()-1; i>=0; i--) {
			String carRomano = (numRomano.charAt(i) + "").toUpperCase(); 
			if (!this.equivalenciasRomanoArabe.containsKey(carRomano)) {
				throw new Exception("Carácter " + carRomano + " en número romano " + numRomano + " no es válido");
			} else {
				int valor = this.roman2Decimal.get(this.equivalenciasRomanoArabe.get(carRomano));
				if (valor >= maxRomanDigit) {
					maxRomanDigit = valor;
					valorArabeCalculado += valor;
				} else {
					valorArabeCalculado -= valor;
				}
			}
		}
		return valorArabeCalculado;
    }


	/**
	* Method handling HTTP GET requests. The returned object will be sent
	* to the client as "text/xml" media type.
	*
	* @return String containing XML message with the conversion from roman number to arab number.
	*/
	@GET
	@Path("/roman/{param}")
	@Produces(MediaType.APPLICATION_XML)
	@ApiOperation(value="conversor from roman number to arab number")
	public String convertRoman2Arab(@ApiParam(value="param",required=true)@PathParam("param") String num) {
		String msg = "";
		String resultStr ="";
		try {
			resultStr = (new Integer(convertRoman2Decimal(num))).toString();
			msg = "<message>" + resultStr + "</message>";
			this.saveConversion("roman2Arab", num, resultStr);
		} catch (Exception e) {
			resultStr = e.getMessage();
			msg = "<message>ERROR: " + resultStr + "</message>"; 
		} 
		
		return "<?xml version=\"1.0\"?>" + msg;
		
		
	}
	
	/**
	* Method handling HTTP GET requests. The returned object will be sent
	* to the client as "text/xml" media type.
	*
	* @return String containing XML message with the conversion from arab number to roman number.
	*/
	@GET
	@Path("/arab/{param}")
	@Produces(MediaType.APPLICATION_XML)
	@ApiOperation(value="conversor from arab number to roman number")
	public String convertArab2Roman(@ApiParam(value="param",required=true)@PathParam("param") int numDecimal) {
		String msg = "";
		//int numDecimal = -1;
		//try {
		//	numDecimal = Integer.parseInt(num);
		String romanStr = "";
		if (numDecimal >= 4000) {
			msg = "<message>ERROR: Número decimal (" + numDecimal + ") pasado mayor que 4000</message>";
		} else {
			try {
				romanStr = convertDecimal2Roman(numDecimal);
				msg = "<message>" + romanStr + "</message>";
				this.saveConversion("arab2Roman", (new Integer(numDecimal)).toString(), romanStr);
			} catch (Exception e) {
				msg = "<message>ERROR: " + e.getMessage() + "</message>"; 
			}
		}
		//} catch (NumberFormatException nfe) {
		//	msg = "<message>ERROR: Número decimal (" + num + ") pasado no es correcto</message>"; 
		//}	
		return "<?xml version=\"1.0\"?>" + msg;
	}
	
	
	@GET
	@Path("/latest")
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value="returns the list of last conversions")
	public List<Conversion> conversions() {
		List<Conversion> conversions = ObjectifyService.ofy()
          .load()
          .type(Conversion.class) // We want only Conversions
          .order("-date")       // Most recent first - date is indexed.
          .limit(5)             // Only show 5 of them.
          .list();	
		return conversions;	
	}
	
	private void saveConversion(String type, String value, String result) throws java.io.IOException {
		Conversion conversion = new Conversion(type, value, result);
		
		// Use Objectify to save the conversion and now() is used to make the call synchronously as we want the data to be present.
		ObjectifyService.ofy().save().entity(conversion).now();
	}
}
